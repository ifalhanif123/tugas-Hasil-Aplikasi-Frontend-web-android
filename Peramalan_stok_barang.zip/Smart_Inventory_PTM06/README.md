# Smart Inventory PTM-06 — Frontend dan Backend Terpisah

Proyek disusun dalam dua bagian agar mudah dikembangkan dan dijalankan:

- `frontend/` — antarmuka HTML, CSS, dan JavaScript.
- `backend/` — API FastAPI, autentikasi, model data, transaksi stok, dan prediksi Random Forest.
- `docs/` — dokumen pendukung, koleksi Postman, catatan keamanan, dan prompt log.
- `tests/` — berkas uji/dokumentasi pengujian yang tersedia.

## 1. Persiapan PostgreSQL

Buat database PostgreSQL bernama `smart_inventory`, lalu sesuaikan user dan password pada `backend/.env`.

## 2. Jalankan backend (Terminal 1)

Di Windows 10, buka terminal pada folder `backend`:

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Edit `backend/.env` dan atur `DATABASE_URL` ke PostgreSQL lokal serta ganti `SECRET_KEY` dengan nilai rahasia yang kuat. Lalu jalankan:

```bat
uvicorn app.main:app --reload --port 8000
```

API: `http://127.0.0.1:8000`
Dokumentasi API: `http://127.0.0.1:8000/docs`

## 3. Jalankan frontend (Terminal 2)

Buka terminal kedua pada folder `frontend`, lalu jalankan:

```bat
py -m http.server 5500
```

Buka `http://127.0.0.1:5500` di browser. Frontend telah dikonfigurasi memanggil API di `http://127.0.0.1:8000`; backend mengizinkan CORS untuk alamat frontend lokal tersebut.

## 4. Catatan penting

- Frontend dan backend sengaja dipisahkan ke folder masing-masing, tetapi terhubung melalui endpoint HTTP API.
- Database PostgreSQL harus aktif dan `.env` harus benar sebelum API dapat beroperasi.
- Screenshot untuk laporan harus diambil dari aplikasi yang benar-benar sudah dijalankan. ZIP ini belum membuktikan koneksi PostgreSQL atau semua alur fitur berjalan pada komputer pengguna.
- Endpoint yang tersedia dapat dilihat melalui `/docs`. Jika ada perbedaan kontrak endpoint, gunakan dokumentasi API sebagai acuan.
